<?php 

// require 'public/login.php';
header("Location: public/user/login.php");

?>

