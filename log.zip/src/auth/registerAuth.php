<?php
require_once __DIR__ . '/../user/profile.php';
require_once __DIR__ . '/../user/account.php';

function CreateNewUserAccount($arrayInfo) {
    try {
        $userProfile = new profileMng();
        $userAcc = new UserAcc();

        $firstName = sanitizeInput($arrayInfo['firstName']);
        $lastName = sanitizeInput($arrayInfo['lastName']);
        $gender = isset($arrayInfo['gender']) ? sanitizeInput($arrayInfo['gender']) : null;
        $dob = isset($arrayInfo['dob']) ? sanitizeInput($arrayInfo['dob']) : null;
        $number = sanitizeInput($arrayInfo['number']);
        $email = sanitizeInput($arrayInfo['email']);
        $username = sanitizeInput($arrayInfo['username']);
        $pass = sanitizeInput($arrayInfo['pass']);

        // Check if username is already registered

        if ($userAcc->isUsernameRegistered($username)) {
            // echo 'Yes';
            throw new Exception('Already Have Username');
        }

        //attempt to create a profile
        
        $profileResult = $userProfile->addProfile($firstName, $lastName, $gender, $dob);
        if (isset($profileResult['error'])) {
            throw new Exception('Profile creation failed: ' . $profileResult['error']);
        }
        $pgCode = $profileResult['pgID']; 
        // var_dump($number);
        $regResult = $userAcc->register($username, $pass, $number, $pgCode, $email);
        if ($regResult['status'] == 'error') {
            $userProfile->deleteUser($pgCode);
            throw new Exception('Account registration failed ') ;
        }

        return [
            'response' => 'success',    
        ];
    } catch (Exception $er) {
        error_log('CreateNewUserAccount error: ' . $er->getMessage());
        return ['message' => $er->getMessage(),
        'response' => 'error'];
    }
}
