<?php 

// if (isset($_SESSION['user']) && (!isset($_SESSION['isOtpVerified']) || $_SESSION['isOtpVerified'] === 0)) {
//     //redirect to otp if not verified
//     echo 'Must not trigger Beacuse it is for manual inster of link';
//     // header("Location: ../public/otp.php");
//     exit;
// }

if (!isset($_SESSION['user'])) {
    header("Location: ../public/login.php");
    exit;
}

?>